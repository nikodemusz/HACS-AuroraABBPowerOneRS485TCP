## Summary

Describe the change.

## Testing

- [ ] Config flow tested
- [ ] Polling tested
- [ ] Translations updated if needed
- [ ] Changelog updated if needed

## Notes

Add any migration notes or caveats here.
